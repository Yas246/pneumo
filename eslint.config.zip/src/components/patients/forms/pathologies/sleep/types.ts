import { FormSectionProps as BaseFormSectionProps } from "../../types";

export type FormSectionProps = BaseFormSectionProps;
