import { z } from "zod";

export const pidSchema = z.object({
  // Motif d'admission
  pidAdmissionReason: z.string().optional(),

  // Antécédents toxiques
  pidToxicHistory: z
    .object({
      smoking: z
        .object({
          present: z.boolean().default(false),
          type: z
            .object({
              active: z.boolean().default(false),
              passive: z.boolean().default(false),
            })
            .default({}),
          packYears: z.number().optional(),
          startAge: z.number().optional(),
          stopped: z.boolean().default(false),
        })
        .default({}),
      alcoholism: z.boolean().default(false),
      drugAddiction: z
        .object({
          present: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      longTermMedication: z
        .object({
          present: z.boolean().default(false),
          products: z.string().optional(),
          duration: z.string().optional(),
        })
        .default({}),
      medicinalPlants: z
        .object({
          present: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
    })
    .default({}),

  // Antécédents médicaux
  pidMedicalHistory: z
    .object({
      tuberculosis: z
        .object({
          present: z.boolean().default(false),
          form: z.string().optional(),
          date: z.string().optional(),
          treatment: z.string().optional(),
          evolution: z.string().optional(),
        })
        .default({}),
      asthma: z
        .object({
          present: z.boolean().default(false),
          since: z.string().optional(),
        })
        .default({}),
      hypersensitivity: z.boolean().default(false),
      chronicBronchitis: z
        .object({
          present: z.boolean().default(false),
          details: z.string().optional(),
          duration: z.string().optional(),
        })
        .default({}),
      otherRespiratoryDiseases: z.string().optional(),
      diabetes: z
        .object({
          present: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      hypertension: z
        .object({
          present: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      gerd: z
        .object({
          present: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      heartDisease: z
        .object({
          present: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      systemicDisease: z
        .object({
          present: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      neoplasia: z
        .object({
          present: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      gastroesophagealReflux: z.boolean().default(false),
      otherAntecedents: z.string().optional(),
    })
    .default({}),

  // Antécédents gynéco-obstétricaux (uniquement pour les femmes)
  pidGynecoObstetricHistory: z
    .object({
      menarche: z.string().optional(),
      cycle: z.enum(["", "Régulier", "Irrégulier"]).optional(),
      gestity: z.number().optional(),
      parity: z.number().optional(),
      contraceptives: z.string().optional(),
    })
    .default({}),

  // Mode de vie
  pidLifestyle: z
    .object({
      professionalExposure: z
        .object({
          present: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      avianContact: z
        .object({
          present: z.boolean().default(false),
          description: z.string().optional(),
        })
        .default({}),
      moltyHayContact: z.boolean().default(false),
      tropicalTravel: z
        .object({
          present: z.boolean().default(false),
          location: z.string().optional(),
        })
        .default({}),
      otherExposures: z.string().optional(),
    })
    .default({}),

  // Antécédents familiaux
  pidFamilyHistory: z
    .object({
      similarCaseInFamily: z.boolean().default(false),
      autoImmuneDisease: z
        .object({
          present: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
    })
    .default({}),

  // Histoire de la maladie
  pidDiseaseHistory: z
    .object({
      symptomsDuration: z.enum(["", "<3 semaines", ">3 semaines"]).optional(),
      installationMode: z.enum(["", "Brutal", "Progressif"]).optional(),
    })
    .default({}),

  // Signes respiratoires
  pidRespiratorySymptoms: z
    .object({
      cough: z
        .object({
          present: z.boolean().default(false),
          type: z.enum(["", "Sèche", "Productive"]).optional(),
          intensity: z
            .object({
              insomnia: z.boolean().default(false),
              emetic: z.boolean().default(false),
              painful: z.boolean().default(false),
              withUrinaryIncontinence: z.boolean().default(false),
            })
            .default({}),
          frequency: z.enum(["", "Permanente", "Saisonnière"]).optional(),
          timing: z.enum(["", "Nocturne", "Diurne"]).optional(),
          triggers: z
            .object({
              noFactor: z.boolean().default(false),
              tobacco: z.boolean().default(false),
              postMeal: z.boolean().default(false),
              duringMeal: z.boolean().default(false),
              decubitus: z.boolean().default(false),
              other: z.string().optional(),
            })
            .default({}),
        })
        .default({}),
      dyspnea: z
        .object({
          present: z.boolean().default(false),
          sadoulStage: z.enum(["", "I", "II", "III", "IV"]).optional(),
          type: z.enum(["", "Permanente", "Paroxystique"]).optional(),
          circumstances: z
            .object({
              effort: z.boolean().default(false),
              rest: z.boolean().default(false),
              decubitus: z.boolean().default(false),
              other: z.string().optional(),
            })
            .default({}),
        })
        .default({}),
      chestPain: z
        .object({
          present: z.boolean().default(false),
          location: z
            .object({
              right: z.boolean().default(false),
              left: z.boolean().default(false),
              bilateral: z.boolean().default(false),
            })
            .default({}),
          site: z
            .object({
              medioThoracic: z.boolean().default(false),
              basiThoracic: z.boolean().default(false),
              retrosternal: z.boolean().default(false),
              diffuse: z.boolean().default(false),
            })
            .default({}),
          type: z
            .object({
              oppression: z.boolean().default(false),
              constrictive: z.boolean().default(false),
              burning: z.boolean().default(false),
              other: z.string().optional(),
            })
            .default({}),
          triggers: z.string().optional(),
        })
        .default({}),
      hemoptysis: z
        .object({
          present: z.boolean().default(false),
          abundance: z.enum(["", "Faible", "Moyenne", "Grande"]).optional(),
        })
        .default({}),
      expectoration: z
        .object({
          present: z.boolean().default(false),
          frequency: z.enum(["", "Permanente", "Intermittente"]).optional(),
          timing: z.enum(["", "Matinal", "Non matinal"]).optional(),
          quality: z
            .enum(["", "Muqueuse", "Muco-purulente", "Purulente"])
            .optional(),
          quantity: z.enum(["", "Grande", "Faible"]).optional(),
          odor: z.string().optional(),
        })
        .default({}),
    })
    .default({}),

  // Signes extra-respiratoires
  pidExtraRespiratorySymptoms: z
    .object({
      arthralgia: z
        .object({
          present: z.boolean().default(false),
          type: z.enum(["", "Inflammatoire", "Mécanique"]).optional(),
        })
        .default({}),
      xerophthalmia: z.boolean().default(false),
      xerostomia: z.boolean().default(false),
      cutaneousSigns: z
        .object({
          present: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      neurologicalSigns: z
        .object({
          present: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      digestiveSigns: z
        .object({
          present: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
    })
    .default({}),

  // Signes généraux
  pidGeneralSigns: z
    .object({
      asthenia: z.boolean().default(false),
      anorexia: z.boolean().default(false),
      weightLoss: z
        .object({
          present: z.boolean().default(false),
          quantified: z
            .object({
              present: z.boolean().default(false),
              value: z.number().optional(),
            })
            .default({}),
        })
        .default({}),
      fever: z
        .object({
          present: z.boolean().default(false),
          quantified: z
            .object({
              present: z.boolean().default(false),
              value: z.number().optional(),
            })
            .default({}),
        })
        .default({}),
      nightSweats: z.boolean().default(false),
    })
    .default({}),

  // Examen clinique
  pidClinicalExam: z
    .object({
      inspection: z.string().optional(),
      palpation: z.string().optional(),
      percussion: z.string().optional(),
      auscultation: z.string().optional(),
      extrapulmonaryExam: z
        .object({
          cardiovascular: z.string().optional(),
          abdominal: z.string().optional(),
          neurological: z.string().optional(),
          osteoarticular: z.string().optional(),
          cutaneous: z.string().optional(),
          lymphNodes: z.string().optional(),
          otherFindings: z.string().optional(),
        })
        .default({}),
      pleuroPulmonaryExam: z
        .object({
          normal: z.boolean().default(false),
        })
        .default({}),
      lymphNodes: z
        .object({
          normal: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      cardiovascularExam: z
        .object({
          normal: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      cutaneousExam: z
        .object({
          normal: z.boolean().default(false),
          symptoms: z.array(z.string()).optional(),
          location: z.string().optional(),
          type: z.string().optional(),
          details: z.string().optional(),
        })
        .default({}),
      ent: z
        .object({
          normal: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      jointExam: z
        .object({
          normal: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      neurologicalExam: z
        .object({
          normal: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      abdominalExam: z
        .object({
          normal: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      ophthalmologicExam: z
        .object({
          normal: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      renalExam: z
        .object({
          normal: z.boolean().default(false),
          details: z.string().optional(),
        })
        .default({}),
      generalExam: z
        .object({
          normal: z.boolean().default(false),
          weight: z.number().optional(),
          height: z.number().optional(),
          bmi: z.number().optional(),
          temperature: z.number().optional(),
          bloodPressure: z.string().optional(),
          heartRate: z.number().optional(),
          respiratoryRate: z.number().optional(),
          saturation: z.number().optional(),
        })
        .default({}),
    })
    .default({}),

  // Examens complémentaires
  pidComplementaryExams: z
    .object({
      chestXRay: z
        .object({
          done: z.boolean().default(false),
          date: z.string().optional(),
          normalFindings: z.string().optional(),
          type: z.string().optional(),
          location: z.string().optional(),
          distribution: z.string().optional(),
        })
        .default({}),
      chestCT: z
        .object({
          done: z.boolean().default(false),
          date: z.string().optional(),
          findings: z.string().optional(),
          location: z.string().optional(),
          type: z.string().optional(),
          distribution: z.string().optional(),
        })
        .default({}),
      handXRay: z
        .object({
          done: z.boolean().default(false),
          findings: z.string().optional(),
        })
        .default({}),
      sinusCT: z
        .object({
          done: z.boolean().default(false),
          findings: z.string().optional(),
        })
        .default({}),
      biology: z
        .object({
          cbc: z
            .object({
              done: z.boolean().default(false),
              hemoglobin: z.number().optional(),
              mcv: z.number().optional(),
              whiteBloodCells: z.number().optional(),
              neutrophils: z.number().optional(),
              eosinophils: z.number().optional(),
              lymphocytes: z.number().optional(),
              platelets: z.number().optional(),
            })
            .default({}),
          biochemistry: z
            .object({
              done: z.boolean().default(false),
              creatinine: z.number().optional(),
              clearance: z.number().optional(),
              ast: z.number().optional(),
              alt: z.number().optional(),
              crp: z.number().optional(),
              vs: z.number().optional(),
            })
            .default({}),
          immunology: z
            .object({
              done: z.boolean().default(false),
              anca: z.string().optional(),
              ana: z.string().optional(),
              rheumatoidFactor: z.string().optional(),
              antiCcp: z.string().optional(),
              otherDetails: z.string().optional(),
            })
            .default({}),
          viralSerology: z
            .object({
              done: z.boolean().default(false),
              hiv: z.string().optional(),
              hbv: z.string().optional(),
              hcv: z.string().optional(),
            })
            .default({}),
        })
        .default({}),
      microbiology: z
        .object({
          done: z.boolean().default(false),
          bkSputum: z.string().optional(),
          ecbc: z.string().optional(),
          pcr: z.string().optional(),
          tuberculosisTest: z.string().optional(),
          otherTests: z.string().optional(),
        })
        .default({}),
      bronchoscopy: z
        .object({
          done: z.boolean().default(false),
          findings: z.string().optional(),
          bal: z
            .object({
              done: z.boolean().default(false),
              result: z.string().optional(),
            })
            .default({}),
          bronchialEndoscopy: z
            .object({
              done: z.boolean().default(false),
              result: z.string().optional(),
            })
            .default({}),
        })
        .default({}),
      histology: z
        .object({
          done: z.boolean().default(false),
          lymphNodeBiopsy: z
            .object({
              result: z.string().optional(),
            })
            .default({}),
          pleuralBiopsy: z
            .object({
              result: z.string().optional(),
            })
            .default({}),
          skinBiopsy: z
            .object({
              result: z.string().optional(),
            })
            .default({}),
          otherBiopsy: z
            .object({
              result: z.string().optional(),
            })
            .default({}),
        })
        .default({}),
      phthisiology: z
        .object({
          done: z.boolean().default(false),
          result: z.string().optional(),
        })
        .default({}),
      functionalAssessment: z
        .object({
          done: z.boolean().default(false),
          pulmonaryFunctionTest: z.string().optional(),
          ecg: z.string().optional(),
          echocardiography: z.string().optional(),
          walkTest: z.string().optional(),
          bloodGas: z.string().optional(),
          efr: z.string().optional(),
        })
        .default({}),
    })
    .default({}),

  // Diagnostic final
  pidFinalDiagnosis: z
    .object({
      diagnosisType: z
        .object({
          idiopathicPulmonaryFibrosis: z.boolean().default(false),
          sarcoidosis: z.boolean().default(false),
          rheumatoidArthritis: z.boolean().default(false),
          hypersensitivityPneumonitis: z.boolean().default(false),
          scleroderma: z.boolean().default(false),
          mixedConnectiveTissueDisease: z.boolean().default(false),
          drugInducedIld: z.boolean().default(false),
          indeterminateIld: z.boolean().default(false),
          other: z.string().optional(),
        })
        .default({}),
    })
    .default({}),
});

export type PIDFormData = z.infer<typeof pidSchema>;
